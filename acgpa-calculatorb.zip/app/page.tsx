"use client";

import { useState } from "react";
import RangeAnalyzer from "./components/RangeAnalyzer";
import TopperFinder from "./components/TopperFinder";

export default function Home() {
  const [mode, setMode] = useState<"single" | "range" | "topper">("single");
  const [rangeResults, setRangeResults] = useState<any[]>([]);

  /* ---------------- SINGLE STUDENT ---------------- */
  const [reg, setReg] = useState("");
  const [singleResult, setSingleResult] = useState<any>(null);
  const [loadingSingle, setLoadingSingle] = useState(false);

  async function checkSingle() {
    if (!reg) return;
    setLoadingSingle(true);
    setSingleResult(null);

    try {
      const res = await fetch(`/api/result?reg=${reg}`);
      const data = await res.json();
      setSingleResult(data);
    } catch (e) {
      setSingleResult({ error: "Failed to fetch result" });
    }

    setLoadingSingle(false);
  }

  /* ------------------------------------------------ */

  return (
    <main className="max-w-4xl mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">
        UAF Result Checker
      </h1>

      {/* MODE BUTTONS */}
      <div className="flex gap-3 mb-6">
        <button
          onClick={() => setMode("single")}
          className="border px-3 py-1 rounded"
        >
          Single Student
        </button>

        <button
          onClick={() => setMode("range")}
          className="border px-3 py-1 rounded"
        >
          Range Results
        </button>

        <button
          onClick={() => setMode("topper")}
          className="border px-3 py-1 rounded"
        >
          Topper Finder
        </button>
      </div>

      {/* ---------------- SINGLE MODE ---------------- */}
      {mode === "single" && (
        <div>
          <h2 className="text-xl font-semibold mb-2">
            Single Student Result
          </h2>

          <input
            className="border p-2 mr-2"
            placeholder="2023-ag-4170"
            value={reg}
            onChange={(e) => setReg(e.target.value)}
          />

          <button
            onClick={checkSingle}
            className="border px-3 py-2 rounded"
            disabled={loadingSingle}
          >
            {loadingSingle ? "Checking..." : "Check Result"}
          </button>

          {singleResult && (
            <pre className="mt-4 p-3 bg-gray-100 text-sm overflow-auto">
              {JSON.stringify(singleResult, null, 2)}
            </pre>
          )}
        </div>
      )}

      {/* ---------------- RANGE MODE ---------------- */}
      {mode === "range" && (
        <RangeAnalyzer onComplete={setRangeResults} />
      )}

      {/* ---------------- TOPPER MODE ---------------- */}
      {mode === "topper" && (
        <TopperFinder results={rangeResults} />
      )}
    </main>
  );
}