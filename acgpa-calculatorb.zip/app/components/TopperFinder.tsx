"use client";

import { useState } from "react";

type Props = {
  results: any[];
};

export default function TopperFinder({ results }: Props) {
  const [courseCode, setCourseCode] = useState("FST-505");
  const [toppers, setToppers] = useState<any[]>([]);
  const [error, setError] = useState("");

  function findToppers() {
    setError("");
    setToppers([]);

    if (!results || results.length === 0) {
      setError("No range results found. Please run Range Analyzer first.");
      return;
    }

    const extracted: any[] = [];

    for (const r of results) {
      // safety checks
      if (!r || !r.html) continue;

      try {
        const parser = new DOMParser();
        const doc = parser.parseFromString(r.html, "text/html");

        // result table usually second table
        const tables = doc.querySelectorAll("table");
        if (tables.length < 2) continue;

        const rows = tables[1].querySelectorAll("tr");

        rows.forEach((row) => {
          const cells = row.querySelectorAll("td");
          if (cells.length < 5) return;

          const code = cells[0].innerText.trim();
          const marksText = cells[cells.length - 2].innerText.trim();

          if (code === courseCode) {
            const marks = parseFloat(marksText);

            if (!isNaN(marks)) {
              extracted.push({
                reg: r.reg,
                marks
              });
            }
          }
        });
      } catch {
        // ignore parsing errors
      }
    }

    if (extracted.length === 0) {
      setError(`No students found for course ${courseCode}`);
      return;
    }

    extracted.sort((a, b) => b.marks - a.marks);

    setToppers(extracted.slice(0, 20));
  }

  return (
    <div>
      <h2 className="text-xl font-semibold mb-3">
        Topper Finder
      </h2>

      {/* INPUT */}
      <div className="flex gap-2 mb-3">
        <input
          className="border p-2"
          placeholder="Course Code (FST-505)"
          value={courseCode}
          onChange={(e) => setCourseCode(e.target.value)}
        />

        <button
          onClick={findToppers}
          className="border px-4 py-2 rounded"
        >
          Find Top 20
        </button>
      </div>

      {/* ERROR */}
      {error && (
        <div className="text-red-600 mb-3">
          {error}
        </div>
      )}

      {/* RESULT TABLE */}
      {toppers.length > 0 && (
        <div className="overflow-auto">
          <table className="border w-full text-sm">
            <thead className="bg-gray-100">
              <tr>
                <th className="border p-2">Rank</th>
                <th className="border p-2">Registration</th>
                <th className="border p-2">Marks</th>
              </tr>
            </thead>
            <tbody>
              {toppers.map((t, idx) => (
                <tr key={idx}>
                  <td className="border p-2 text-center">
                    {idx + 1}
                  </td>
                  <td className="border p-2">
                    {t.reg}
                  </td>
                  <td className="border p-2 text-center">
                    {t.marks}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}