"use client";

import { useState } from "react";

type Props = {
  onComplete: (results: any[]) => void;
};

export default function RangeAnalyzer({ onComplete }: Props) {
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [progress, setProgress] = useState(0);
  const [running, setRunning] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [results, setResults] = useState<any[]>([]);

  async function startRangeCheck() {
    if (!start || !end) {
      alert("Please enter start and end numbers");
      return;
    }

    const startNum = parseInt(start);
    const endNum = parseInt(end);

    if (isNaN(startNum) || isNaN(endNum) || startNum > endNum) {
      alert("Invalid range");
      return;
    }

    const total = endNum - startNum + 1;

    setRunning(true);
    setProgress(0);
    setLogs([]);
    setResults([]);

    const collected: any[] = [];

    for (let i = startNum; i <= endNum; i++) {
      const reg = `2023-ag-${i}`;
      setLogs((prev) => [...prev, `Fetching ${reg}...`]);

      try {
        const res = await fetch(`/api/result?reg=${reg}`);
        const data = await res.json();

        collected.push({
          reg,
          ...data
        });

        setResults([...collected]);
      } catch (err) {
        collected.push({
          reg,
          error: "Fetch failed"
        });
      }

      const done = i - startNum + 1;
      setProgress(Math.round((done / total) * 100));

      // VERY IMPORTANT: delay to avoid LMS blocking
      await new Promise((r) => setTimeout(r, 700));
    }

    setRunning(false);
    onComplete(collected);

    setLogs((prev) => [...prev, "✅ Range fetching completed"]);
  }

  return (
    <div>
      <h2 className="text-xl font-semibold mb-3">
        Range Result Analyzer
      </h2>

      {/* INPUTS */}
      <div className="flex gap-2 mb-3">
        <input
          className="border p-2 w-28"
          placeholder="Start (4170)"
          value={start}
          onChange={(e) => setStart(e.target.value)}
          disabled={running}
        />

        <input
          className="border p-2 w-28"
          placeholder="End (4250)"
          value={end}
          onChange={(e) => setEnd(e.target.value)}
          disabled={running}
        />

        <button
          onClick={startRangeCheck}
          disabled={running}
          className="border px-4 py-2 rounded"
        >
          {running ? "Running..." : "Start"}
        </button>
      </div>

      {/* PROGRESS */}
      <div className="mb-3">
        <b>Progress:</b> {progress}%
        <div className="w-full bg-gray-200 h-2 mt-1">
          <div
            className="bg-green-600 h-2"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* LOGS */}
      <div className="mb-4 max-h-40 overflow-auto bg-gray-50 p-2 text-sm border">
        {logs.map((log, idx) => (
          <div key={idx}>{log}</div>
        ))}
      </div>

      {/* QUICK SUMMARY */}
      {results.length > 0 && (
        <div className="text-sm text-gray-700">
          Fetched <b>{results.length}</b> results
        </div>
      )}
    </div>
  );
}